// console.log("main js file is now going to be loaded");

requirejs.config({
    // baseUrl: "", // this breaks it
    
    paths: {
        'vue': 'local_utools/vue',
        // 'vue-easytable': '/local/tcs/amd_not/vue-easytable',
        // 'vue-easytable': '/local/tcs/js/vue-easytable',
        'vue-easytable': '/local/tcs/amd_not/vue-easytable_converted',
        // 'vue-router': 'local_utools/vue-router',
        // 'axios': 'local_utools/axios',
        // 'routes': 'local_utools/routes',
        // 'moment': 'local_utools/moment',
        // 'fullcalendar': 'local_utools/fullcalendar'
    },
    
    shim: {
        // vue: {
        //     exports: 'Vue'
        // },
        // vue_router: {
        //     exports: 'VueRouter'
        // },
        // routes: {
        //     exports: 'routes'
        // },
        // moment: {
        //     exports: 'moment'
        // },
        // fullcalendar: {
        //     deps: ['jquery', 'moment'],
        //     exports: 'fullcalendar'
        // }
        'vue-easytable': {
            deps: ['local_utools/vue'],
            exports: 'vue-easytable'
        }
    }
});


// Libraries used in this Dashboard are:
// Fullcalendar: https://fullcalendar.io/
// Moment: https://momentjs.com/
// NOPE - Couldn't get this working. vue-datatables: https://onewaytech.github.io/vue2-datatable/doc/#/en/getting-started
// https://github.com/huangshuwei/vue-easytable
// possible fix for shim: https://docs.exoplatform.org/public/index.jsp?topic=%2FPLF43%2FPLFDevGuide.JavaScript.Shim_and_NonAMD.html

define(function () {
        'use strict';
        console.log("Config.js -> Loaded");
        return {

            init: function () {

                
            }
        };
    }
);

define(['local_utools/vue'], function (Vue) {

    return Vue.extend({
        template: '<div class="col-md-3 col-lg-2 sidebar-offcanvas bg-light pl-0" id="sidebar" role="navigation">' +
                '<ul class="nav flex-column sticky-top pl-0 mt-3">' +
                    '<li class="nav-item">' +
                        '<router-link to=\'dashboard\'>' +
                            '<a href="#" class="nav-link">' +
                                '<i class="fa fa-dashboard"></i>' +
                                '<span class="d-none d-md-inline">' +
                                    'Dashboard' +
                                '</span>' +
                            '</a>' +
                        '</router-link>' +
                    '</li>' +
                    '<!-- ******************************** -->' +
                    '<li class="nav-item">' +
                        '<router-link to=\'reporting\'>' +
                            '<a href="#" class="nav-link">' +
                                '<i class="fa fa-calendar"></i>' +
                                '<span class="d-none d-md-inline">' +
                                    'Reporting' +
                                '</span>' +
                            '</a>' +
                        '</router-link>' +
                    '</li>' +
                    '<!-- ******************************** -->' +
                    '<li class="nav-item">' +
                        '<a class="nav-link" href="#submenu1" data-toggle="collapse" data-target="#submenu1">Enrol / LMB ▾</a>' +
                        '<ul class="list-unstyled flex-column pl-3 collapse" id="submenu1" aria-expanded="false">' +
                           '<li class="nav-item">' +
                                '<router-link to=\'live_logs\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Live LMB Log' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                           '<li class="nav-item">' +
                                '<router-link to=\'dead_enroll\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Dead Enrollments' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                           '<li class="nav-item">' +
                                '<router-link to=\'unenroll\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Unenroll A User' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                           '<li class="nav-item">' +
                                '<router-link to=\'banner_compare\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Banner Compare Tool' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                        '</ul>' +
                    '</li>' +
                    '<!-- ******************************** -->' +
                    '<li class="nav-item">' +
                        '<a class="nav-link" href="#submenu2" data-toggle="collapse" data-target="#submenu2">DB Tools ▾</a>' +
                        '<ul class="list-unstyled flex-column pl-3 collapse" id="submenu2" aria-expanded="false">' +
                           '<li class="nav-item">' +
                                '<router-link to=\'view_courses\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Courses w/ Students' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                           '<li class="nav-item">' +
                                '<router-link to=\'missing_id\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Find Missing ID\'s' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                           '<li class="nav-item">' +
                                '<router-link to=\'course_restore\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Course Restore' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                           '<li class="nav-item">' +
                                '<router-link to=\'mass_enroll\'>' +
                                    '<a href="#" class="nav-link">' +
                                        'Mass Enroll' +
                                    '</a>' +
                                '</router-link>' +
                           '</li>' +
                        '</ul>' +
                    '</li>' +
                    '<!-- ******************************** -->' +
                    '<li class="nav-item">' +
                        '<router-link to=\'logs\'>' +
                            '<a href="#" class="nav-link">' +
                                '<i class="fa fa-list-alt"></i>' +
                                '<span class="d-none d-md-inline">' +
                                    'Logs' +
                                '</span>' +
                            '</a>' +
                        '</router-link>' +
                    '</li>' +
                    '<!-- ******************************** -->' +
                    '<li class="nav-item">' +
                        '<router-link to=\'settings\'>' +
                            '<a href="#" class="nav-link">' +
                                '<i class="fa fa-cog"></i>' +
                                '<span class="d-none d-md-inline">' +
                                    'Settings' +
                                '</span>' +
                            '</a>' +
                        '</router-link>' +
                    '</li>' +
                    '<li class="nav-item"><a class="nav-link" href="#">Utools Link Empty</a></li>' +
                '</ul>' +
            '</div>',

        data: function() {
            return {

            };
        },
    });
});

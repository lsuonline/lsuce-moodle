/*jslint es6: true */
define(['jquery', 'local_utools/vue', 'local_utools/jquery.easypiechart'], function($, Vue) {

    return Vue.extend({

        template: '<div class="col-6 col-sm-3 py-2">' +
                '<div class="card text-white h-100" :class="pie.data.stat_color">' +
                    '<div class="card-body">' +
                        '<div class="rotate">' +
                            '<i :class="pie.data.icon"></i>' +
                        '</div>' +
                        '<div id="da_pie_charts" :class="\'easy_chart_\' + pie.block" :data-pievalue=\'pie.block\' :data-percent=\'pie.data.data\'>' +
                            '{{pie.data.data}}' +
                        '</div>' +
                        '<h4 class="text-uppercase">{{pie.data.title}}</h4>' +
                        '<span class="text-muted">{{pie.data.small_title}}</span>' +
                    '</div>' +
                '</div>' +
            '</div>',

            // Bootstrap Example
            // <div class="col-6 col-sm-3 placeholder text-center">
            //     <img src="//placehold.it/200/dddddd/fff?text=1" class="mx-auto img-fluid rounded-circle" alt="Generic placeholder thumbnail">
            //     <h4>Responsive</h4>
            //     <span class="text-muted">Device agnostic</span>
            // </div>

            // <div class="dash-card-body dash-card-pie">
            //     <div class="card" :class="pie.data.stat_color">
            //         <div class="card-title">
            //             <i :class="pie.data.icon" class="sc-f-size float-left"></i>
            //             <div class="text-uppercase font-weight-bold font-xs sc-title">{{pie.data.title}} {{pie.data.small_title}}</div>
            //         </div>
            //         <div class="card-body text-center p-3 clearfix">
            //             <div id="da_pie_charts" :class="'easy_chart_' + pie.block" :data-pievalue='pie.block' :data-percent='pie.data.data'>{{pie.data.data}}</div>
            //         </div>
            //     </div>
            // </div>`,
        // v-else="pie.use_pie == true"
        //  require('../../styles/stat_card.css'),

        // components: {
        //     VueEasyPieChart: EasyPie
        // },


        props: [
            'pie',
            'index',
        ],

        data: function() {
            return {
                // someValueHere: 0
                pie_chunk: '',
            };
        },

        computed: {

        },

        methods: {
            updatePercent: function(data) {
                // console.log("Made it to updatePercent, what is data: ", data);
                // var nodes = this.$store;
                // console.log("Made it to updatePercent, what is this.$store: ", this.$store);
                // getPieStats

                this.$store.dispatch('changePieBlock', data);
            }
            // getNewRelicData () {
            //     var nodes = this.$store.getters.getNewRelicCalls;
            //     console.log("What is getNewRelicData: ", nodes);
            //     for (var proppy in nodes) {
            //         console.log("What is proppy: ", proppy);
            //         this.$store.dispatch('runAJAXExternal', nodes[proppy]);
            //     }

                /*Utools.runAJAX({
                    // url: 'https://api.newrelic.com/v2/servers/servers/' + Utools.newrelic.sleepy_id + '/metrics/data.json',
                    url: 'https://api.newrelic.com/v2/servers/' + data.server_id + '.json',
                    headers: {
                        "X-Api-Key": this.$store.getters.getNRToken
                    },
                    params: {
                        'params': {
                            'id': data.server_id,
                        },
                    },
                    request: 'POST',
                    storage: data.storage

                }).then(function (result) {

                    Utools.printConsoleMsg({"widget": "newrelic", "msg": "widget_newrelic.js -> simpleAjaxCall() -> RETURNED from NewRelic, what is the results: ", "extra": result});
                    Utools.printConsoleMsg({"widget": "newrelic", "msg": "widget_newrelic.js -> simpleAjaxCall() -> what is the storage: ", "extra": this.storage});

                    Utools.printConsoleMsg({"widget": "newrelic", "msg": "widget_newrelic.js -> simpleAjaxCall() -> what is the health: " + result.server.health_status});

                    $(".nr_title_bars_" + result.server.id).html(result.server.host.toUpperCase());

                    // draw based on what type of chart, pie or number or sparkline....?
                    if (this.storage.data_obj === "easyPieChart") {
                        // console.log("Yup, storage.data_obj === easyPieChart");
                        // cpu
                        // console.log("Going to update this dom: " + this.storage.dom + " and this data_obj: " + this.storage.data_obj +
                            // " with this number: " + result.server.summary.cpu);

                        $(this.storage.dom).data(this.storage.data_obj).update(result.server.summary.cpu);
                        $(this.storage.dom + "_sub").html("Status: " + result.server.health_status);
                        $(this.storage.dom + "_num").html(result.server.summary.cpu + "%");

                        // memory
                        $(this.storage.dom2).data(this.storage.data_obj).update(result.server.summary.memory);
                        $(this.storage.dom2 + "_sub").html("Status: " + result.server.health_status);
                        $(this.storage.dom2 + "_num").html(result.server.summary.memory + "%");

                    } else if (this.storage.data_obj === "number") {
                        // console.log("Yup, storage.data_obj === number");
                        $(this.storage.dom + "_num").html(result.server.summary.cpu);
                        $(this.storage.dom2 + "_num").html(result.server.summary.memory);
                    } else {
                        console.log("ahhhhh crap, storage.data_obj != anything......??????");
                    }

                });
                */
            // }
        },

        mounted: function() {
            /*
            ***************************  NOTE  *****************************
            This get's called 4 times for each pie graph so treat this as 1
            ****************************************************************
            */
            // $('[class^="value"]') <-- starts with string
            // $('[class$="value"]') <-- ends with string
            // $('[class~="value"]') <-- i believe this is the contains string version
            console.log("Da F is this: ", this);
            console.log("what pie piece is this: ", this.pie.block);
            that = this;
            var temp_pie = $('.easy_chart_' + this.pie.block).easyPieChart({
                easing: 'easeOutBounce',
                animate: {
                    enabled: true,
                    duration: 1000
                },

                onStep: function(from, to, currentValue) {
                    $(this.el).data('percent', currentValue); // jQuery
                    // this.el.dataset.percent = currentValue; // vanilla approach
                    // self.$emit('updatePercent', {pie_index: $(this.el).data('pievalue'), 'val': currentValue});
                    // this.$store.dispatch('updatePieBlock', currentValue);
                    // console.log("performed onStep for this pie chart");
                },

                onStop: function(from, to) {
                    $(this.el).data('percent', to); // jQuery
                    // this.el.dataset.percent = to; // vanilla approach
                    // self.$emit('updatePercent', {pie_index: $(this.el).data('pievalue'), 'val': to});
                    // self.$emit('updatePercent', to);
                    that.updatePercent({pie_index: $(this.el).data('pievalue'), 'val': to});
                    // console.log("performed onStop for this pie chart");
                }
            });

            // console.log("pie has been created, what is the pie obj: ", temp_pie);

            this.pie_chunk = temp_pie;
            var temp_math = Math.floor(Math.random() * Math.floor(100));

            // $('.easy_chart_' + this.pie.block).val(temp_math);

            this.pie_chunk.data('easyPieChart').update(temp_math);
            /*
            var dis_many = $('[class^="easy_chart_"]').length;
            // console.log("Finding which this is this, STARTING this is: ", this);
            for (var x = 0; x < dis_many; x++) {
                var temp_name = 'block_' + x;
                // console.log("Finding which this is this, FOR LOOP this is: ", this);
            }

            for (var x = 0; x < dis_many; x++) {
                // $('.easy_chart_' + this.pie.pie_block_num).data('easyPieChart').update(Math.random()*200-100);
                this.list_of_charts['block_' + x].data('easyPieChart').update(temp_math);
                // console.log("What is the temp_math num for easy_chart_" + x + ": " + temp_math);
            }

            
            // $('.chart').data('easyPieChart').update(40);
            
            // var chart = window.chart = $('.easy_chart').data('easyPieChart');
            // $('.js_update').on('click', function() {
            //     chart.update(Math.random()*200-100);
            // });
            */

        }
    });
});
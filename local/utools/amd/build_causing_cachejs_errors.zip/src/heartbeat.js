
define([
    'local_utools/vue',
    'local_utools/vue-router',
    'local_utools/store',

], function(Vue, VueRouter, store) {
        'use strict';
        // Fconsole.log("Main.JS -> Starting up App......");

        // piwik_user_count
        // piwik_max_users_stat
        // tcms_user_count

        /**
         * Get the New Relic Data
         */
        function getNewRelicData() {

            // Fvar nodes = that.$store.getters.getNewRelicCalls;
            // console.log("What is getNewRelicData: ", nodes);

            // for (var proppy in nodes) {

            //     console.log("What is proppy: ", proppy);
            //     that.$store.dispatch('runAJAXExternal', nodes[proppy]);
            // }
        }

        /**
         * Get the New Relic Data
         */
        function getPiwikData () {
            // var piwik_chunk_1 = this.$store.getters.getPiwikCalls;
            console.log("heartbeat.js -> getPiwikData() -> getting this......");
            var piwik_chunk = that.$store.getters.getPiwikData;

            console.log("getPiwikData() -> What is piwik_chunk: ", piwik_chunk);

            for (var x in piwik_chunk) {
                console.log("getPiwikData() -> What is chunk: ", piwik_chunk[x]);
                that.$store.dispatch('runAJAXExternal', piwik_chunk[x]);
            }
        }

        /**
         * Get the TCMS Data
         */
        function getTCMSData () {
            console.log("heartbeat.js -> getTCMSData() -> getting that......");

            var params = {
                'call': 'getCurrentStudentCount',
                'xtra_data': {
                    'ax': true,
                    'page': 0,
                    'total': 0
                },
                'class': 'TcmsAjax',
                "to_dispatch": "updateTCMSUserStat",
                "block_name": ""
            };
            that.$store.dispatch('runAJAX',{
                'params': params,
                // "to_commit": "updateTCMSUserStat"
            });
        }

        return {
            start: function() {
                console.log("heartbeat.js -> Going to start the heartbeat");
                getPiwikData();
                getTCMSData();

                // FsetInterval(function () {
                //     console.log("ba boomp");
                //     getPiwikData();
                //     getTCMSData();
                // }.bind(this), 10000); 

            },
        };
    }
);

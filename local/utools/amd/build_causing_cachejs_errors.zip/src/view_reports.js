
define(['local_utools/vue'], function (Vue) {

    return Vue.extend({
        template: '<div>' +
        '<p>Reports</p>' +
        '<br><br>' +
        'Reports Page.<br>' +
        '</div>',

        data: function() {
            return {
                something_here: 'Hello'
            };
        }
    });
});
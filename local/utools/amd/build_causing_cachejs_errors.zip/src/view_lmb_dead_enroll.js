define(['local_utools/vue'], function (Vue) {

    return Vue.extend({
        template: '<div>' +
                '<p>Dead Enrollments</p>' +
            '</div>',

        data: function() {
            return {

            };
        },
        mounted: function() {
            // console.log("Yes, made it to course restore");
        }
    });
});
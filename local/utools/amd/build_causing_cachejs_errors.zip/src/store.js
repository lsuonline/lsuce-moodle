
define([
    'local_utools/vue',
    'local_utools/vuex',
    'local_utools/store_student',
    'local_utools/store_general',
    'local_utools/store_stats',
    'local_utools/data_fetcher'
], function (Vue, Vuex, StudentStore, GeneralStore, StatsStore, DataFetcher) {
    'use strict';
    Vue.use(Vuex);

    // If there is any data coming from __INITIAL_STATE__ then it'll be injected into the module_general store
    const store = new Vuex.Store({
        strict: true, // Turn this off for production
        actions: DataFetcher,
        modules: {
            student: StudentStore,
            general: GeneralStore,
            stats: StatsStore
        }
    });

    return store;
});
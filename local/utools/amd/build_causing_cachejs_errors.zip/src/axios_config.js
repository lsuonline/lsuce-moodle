define(['local_utools/axios'], function (axios) {
    'use strict';
    // console.log("Main.JS -> Starting up App......");
    var HTTP = axios.create({
        baseURL: 'lib/ajax.php',
        method: 'post',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        config: {
            dispatch: 'spanky_town',
        }
    });

    return HTTP;
});
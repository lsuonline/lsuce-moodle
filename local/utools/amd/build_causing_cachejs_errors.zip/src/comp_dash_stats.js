define(['local_utools/vue', 'local_utools/card_stat', 'local_utools/card_easy_pie'], function (Vue, StatCards, PieStatCards) {

    return Vue.extend({
        name: 'Dashboard-Stats',
        template:
            '<span>' +
                '<div class="row mb-3">' +
                    '<dash-stat v-for="(stat, index, wang) in stats" ' +
                    ':id="index" ' +
                    ':stat="stat"' +
                '></dash-stat>' +
                '</div>' +
                '<hr>' +
                '<div class="row mb-3">' +
                    '<dash-stat-pie v-for="(pie, index) in piestats" ' +
                        ':index="index" :pie="pie" :key="pie.block" v-once></dash-stat-pie>' +
                '</div>' +
            '</span>',

            // :statname="Object.keys(stat)[0]"
            // :key="index"
            // :wang="wang"


            // <div class="utools_dash_stats d-flex flex-row align-items-center justify-items-stretch flex-wrap">
                // <dash-stat v-for="stat in stats" :key="stat.id" :stat="stat"></dash-stat>
                // <dash-stat-pie v-for="(pie, index) in piestats" 
                    // :index="index" :pie="pie" :key="pie.block" v-once></dash-stat-pie>
            // </div>


        // data: function () {
        //     return {

        //     }
        // },

        components: {
            dashStat: StatCards,
            dashStatPie: PieStatCards
        },

        computed: {
            stats: function() {
                // console.log("comp_dash_stats.js -> Going to call getters for stats");
                return this.$store.getters.getFlatStats;
            },
            piestats: function() {
                // console.log("comp_dash_stats.js -> Going to call getters for stats");
                return this.$store.getters.getPieStats;
            }
        },

        methods: {

        },

        // mounted: function() {

        // }
    });
});

define([
    'local_utools/vue',
    'local_utools/vuex',
    'local_utools/comp_checkin_datatable',
    'local_utools/vuetable-ratiw-MyDetailsRow',
    // 'local_utools/comp_auto_complete',

    // 'local_utools/vue_autocomplete', // https://github.com/BosNaufal/vue2-autocomplete
    // 'local_utools/comp_auto_complete3',
    'local_utools/comp_auto_complete', // https://github.com/BosNaufal/vue2-autocomplete
    // http://fareez.info/blog/vuejs/create-your-own-autocomplete-using-vuejs-2/


], function(
    Vue,
    mapGetters,
    CheckinTable,
    DetailRow,
    Autocomplete
) {

    return Vue.extend({
        name: 'Student-Checkin-Form',

        components: {
            checkinTable: CheckinTable,
            DetailRow: DetailRow,
            autocomplete: Autocomplete,
            // autocomplete: Vue2Autocomplete,
        },
        // This works but is extremely slow
        // <autocomplete :suggestions="users" :selection.sync="value"></autocomplete>

        template: '<div class="dash_checkin">' +
                '<div class="card">' +
                    '<div class="card-header">' +
                        '<h3>Student Check In</h3>' +
                    '</div>' +
                    '<div class="card-body">' +
                        '<br>' +
                        '<form @click.prevent="enterUserIntoTC">' +
                            '<div class="row">' +
                                '<!-- LEFT SIDE -->' +
                                '<div class="col-sm-6">' +
                                '<div class="card dash_card card-margin-left">' +
                                '<div class="card-block">' +
                                    '<h4 class="card-title text-center">Student</h4>' +
                                    '<table class="table student_checkin_table"><tbody>' +
                                    '<tr>' +
                                        '<td>' +
                                            '<div class="form-group">' +
                                                '<label for="uofl_id1">UofL ID</label>' +
                                                '<input type="text" v-model="getStudentUoflID" class="form-control" id="uofl_id1" placeholder="UofL ID">' +
                                            '</div>' +
                                            '<div class="form-group">' +
                                                '<label for="uofl_username">Username</label>' +
                                                '<!-- <input type="text" class="form-control" id="uofl_username" placeholder="john.doe"> -->' +
                                                '<autocomplete :suggestions="suggestions" v-model="username_selection">' +
                                                '</autocomplete>' +
                                            '</div>' +
                                        '</td>' +
                                        '<td>' +
                                            '<fieldset class="form-group">' +
                                            '<legend>ID Type</legend>' +
                                            '<div class="form-check form-check" id="tcms_id_chooser">' +
                                                '<label class="form-check-label">' +
                                                    '<input class="form-check-input" type="radio" name="tc_std_list_selectid" id="id_tc_std_list_selectid_0" value="Uofl ID #" checked="checked"> Uofl ID #' +
                                                '</label>' +
                                            '</div>' +
                                            '<div class="form-check form-check" id="tcms_id_chooser">' +
                                                '<label class="form-check-label" id="yui_3_17_2_1_1516831775755_60">' +
                                                    '<input class="form-check-input" type="radio" name="tc_std_list_selectid" id="id_tc_std_list_selectid_1" value="Uofl ID #"> Drivers License' +
                                                '</label>' +
                                            '</div>' +
                                            '<div class="form-check form-check" id="tcms_id_chooser">' +
                                                '<label class="form-check-label">' +
                                                    '<input class="form-check-input" type="radio" name="tc_std_list_selectid" id="id_tc_std_list_selectid_2" value="Uofl ID #"> Passport' +
                                                '</label>' +
                                            '</div>' +
                                            '<div class="form-check form-check" id="tcms_id_chooser">' +
                                                '<label class="form-check-label">' +
                                                    '<input class="form-check-input" type="radio" name="tc_std_list_selectid" id="id_tc_std_list_selectid_3" value="Uofl ID #"> Other (Please Specify in the comments)' +
                                                '</label>' +
                                            '</div>' +
                                            '</fieldset>' +
                                        '</td>' +
                                    '</tr>' +
                                    '</tbody></table>' +
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '<!-- RIGHT SIDE -->' +
                                '<div class="col-sm-6">' +
                                '<div class="card dash_card card-margin-right">' +
                                    '<div class="card-block">' +
                                    '<h4 class="card-title text-center">Exam</h4>' +
                                    '<table class="table student_checkin_table">' +
                                    '<tbody><tr><td>' +
                                        '<div class="form-group">' +
                                            '<label for="studentDropDoExams">Students Exams</label>' +
                                            '<!-- ********************************* -->' +
                                            '<!-- ********************************* -->' +
                                            '<select v-model="utools_exam_selected" v-on:change="onChange" class="form-control" id="studentDropDoExams">' +
                                                '<option ' +
                                                    'v-for="(exam_dd, index) in studentExams"' +
                                                    ':value="exam_dd.value"' +
                                                    ':selected="index === 0 ? \'selected\' : \'\'">' +
                                                    '{{exam_dd.label}}' +
                                                '</option>' +
                                            '</select>' +
                                            '<!-- ********************************* -->' +
                                            '<!-- ********************************* -->' +
                                        '</div>' +
                                        '<div class="form-group utools_mb_0">' +
                                            '<label for="id_tc_std_list_comments">Comments</label>' +
                                            '<textarea v-model="user_comments" id="id_tc_std_list_comments" name="tc_std_list_comments" class="form-control" rows="3"></textarea>' +
                                        '</div>' +
                                    '</td></tr>' +
                                    '</tbody></table>' +
                                    '</div>' +
                                '</div>' +
                                '</div>' +
                            '</div>' +
                            '<!-- BUTTON ROW -->' +
                            '<div class="row">' +
                                '<div class="col-sm-6">' +
                                '<div class="card card-margin-left">' +
                                    '<div class="card-block">' +
                                        '<button id="id_std_list_clear_fields" name="std_list_clear_fields" class="btn btn-warning">Clear Fields</button>' +
                                    '</div>' +
                                '</div>' +
                                '</div>' +
                                '<div class="col-sm-6">' +
                                '<div class="card card-margin-right">' +
                                    '<div class="card-block">' +
                                        '<center><button id="id_tc_std_list_open_std" name="tc_std_list_open_std" class="btn btn-success">Enter Test Room <i class="fa fa-arrow-down"></i></button></center>' +
                                    '</div>' +
                                '</div>' +
                                '</div>' +
                            '</div>' +
                        '</form>' +
                    '</div>' +
                '</div>  ' +
                '<checkinTable' +
                    'apiUrl="lib/ajax.php"' +
                    ':fields="fields"' +
                    ':sortOrder="sortOrder"' +
                    ':appendParams="moreParams"' +
                    ':perPage="perPage"' +
                    ':multiSort="multiSort"' +
                    'detailRowComponent="my-details-row"' +
                '></checkinTable>' +
            '</div>',
        

        /*


        */
        /* <checkinTable
            :append-params="moreParams"
        ></checkinTable>


        <checkinTable
                                api-url="lib/ajax.php"
                                :fields="fields"
                                :sort-order="sortOrder"
                                :append-params="moreParams"
                                detail-row-component="my-details-row"
                                :css="css.table"
                            >
                                <template slot-scope="props">
                                    <custom-actions></custom-actions>
                                </template>

                            </checkinTable>
        */
        // api-url="https://vuetable.ratiw.net/api/users"

        /*
    [id] => 7746
    [username] => david.lowe
    [timesigned] => 2018-03-02 10:42:51-07
    [examfullname] => FUNC-Test-CourseDougs Test Quiz
    [rowid] => moodleexamid7746
    [checkboxvalue] => moodleexamid7746
    [machine_no] => 
    [comments] => 

        */
        data: function() {
            return {
                // For the Autocomplete Form
                // users: this.$store.general.state.user_data,
                users: [],

                value: '',
                // ====================================================
                // For the Exam Dropdown
                // ====================================================
                // exam_dropdown: {
                // studentExams: {
                //     "label": "Select Exam",
                // },
                utools_exam_selected: "Select Exam",
                // v-bind:value="option.value"
                // ====================================================
                // For the UofL ID input 
                uofl_user_id: "UofL ID",
                // For the Comment box
                user_comments: "",
                // ====================================================

                // ====================================================
                // For the Autocomplete 4 Form
                // ====================================================
                username_selection: '',
                suggestions: [],
                
                // ====================================================
                // For the VueTable Form
                // ====================================================
                fields: [
                    // {
                    //     // handle is for a css icon
                    //     name: '__handle',
                    //     titleClass: 'center aligned',
                    //     dataClass: 'center aligned'
                    // }, {
                    //     name: '__checkbox',
                    //     titleClass: 'center aligned',
                    //     dataClass: 'center aligned'
                    // }, {
                    //     // display a sequence of numbers
                    //     name: '__sequence',
                    //     title: '#',
                    //     titleClass: 'center aligned',
                    //     dataClass: 'right aligned'
                    // },
                    '__handle',
                    '__checkbox',
                    '__sequence',
                    {
                        name: 'name',
                        sortField: 'name',
                    }, {
                        name: 'username',
                        // sortField: 'username',
                    }, {
                        name: 'examfullname',
                        // sortField: 'course'
                    }, {
                        name: 'machine_no',
                        // sortField: 'machine_no'
                    }, {
                        name: 'email',
                        // sortField: 'email'
                    }, {
                        name: 'signedin',
                        // sortField: 'signedin',
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned',
                            // callback: ''
                    }, {
                        name: 'comments',
                        // sortField: 'comments',
                            // callback: 'allcap'
                    },

                    {
                      name: '__component:custom-actions',
                      title: 'Actions',
                      titleClass: 'center aligned',
                      dataClass: 'center aligned',
                    }
                ],

                sortOrder: [{
                    field: 'email',
                    sortField: 'email',
                    direction: 'asc'
                }],

                perPage: 10,
                multiSort: true,

                moreParams: {
                    // 'call': 'getCheckedInStudentsTest',
                    'call': 'getCheckedInStudents',
                    'class': 'StudentListAjax',
                },

                // css: {
                //     table: {
                //         tableClass: 'table table-striped table-bordered table-hovered',
                //         loadingClass: 'loading',
                //         ascendingIcon: 'fa fa-chevron-up',
                //         descendingIcon: 'fa fa-chevron-down',
                //         handleIcon: 'fa fa-menu-hamburger',
                //     },
                //     pagination: {
                //         infoClass: 'pull-left',
                //         wrapperClass: 'vuetable-pagination pull-right',
                //         activeClass: 'btn-primary',
                //         disabledClass: 'disabled',
                //         pageClass: 'btn btn-border',
                //         linkClass: 'btn btn-border',
                //         icons: {
                //             first: '',
                //             prev: '',
                //             next: '',
                //             last: '',
                //         },
                //     }
                
                
            };
        },

        methods: {
            onAction: function(action, data, index) {
                console.log('slot action: ' + action, data.name, index);
            },
            // getUsers () {
            //     // getAllUsers
            //     return this.$store.getters.getAllUsers;
            // }

            // ====================================================
            // For the Autocomplete Form
            // ====================================================
            processJSON: function(json) {
                return json.results;
            },
            handleSelect: function(data) {
                this.preContent = JSON.stringify(data, null, 4);
            },

            onChange: function() {
                console.log("Wacka wacka");
            },

            enterUserIntoTC: function(event) {
                console.log("YAY, made it to enterUserIntoTC");

                var params = {
                    'call': 'addStudentToList',
                    'params': {

                        'username': this.username_selection,
                        'exam_id': this.utools_exam_selected,
                        // 'id_type': idType,
                        // 'machine_no': '',
                        'comments': this.user_comments,
                        // 'exam_type': examtype
                    },
                    'class': 'StudentListAjax',
                };
                this.$store.dispatch('runAJAX',{
                    'params': params,
                    "to_dispatch": "studentCheckedIn"
                });

            }
      //       getClassName(part) {
      //   const { classes, className } = this
      //   if (classes[part]) return `${classes[part]}`
      //   return className ? `${className}-${part}` : ''
      // },


        },

        // watch: {
        //     uofl_user_id: function (val1, val2) {

        //         console.log("WATCH: uofl_user_id has changed, what is val1: " + val1);
        //         console.log("WATCH: uofl_user_id has changed, what is val2: " + val2);

        //         return this.$store.getters.getStudentUoflID;
        //     },
        // },


        // mapGetters({
        //     propertyName: 'doubleCounter'
        // },

        computed: {
            // mapGetters([
            //     'getStudentExams',
            //     'getStudentUoflID',
            // ])
            studentExams: function() {
            //     console.log("comp_checkin, studentExams() -> what is this.exam_dropdown: ", this.exam_dropdown);
            //     // this.exam_dropdown = this.$store.getters.getStudentExams;

                console.log("comp_checkin, studentExams() -> has changed.");
                return this.$store.getters.getStudentExams;
            },

            getStudentUoflID: function() {
                return this.$store.getters.getStudentUoflID;
            },
            // stats() {
                // console.log("Going to call getters for getStats");
                // return this.$store.getters.getStats;
            // }
        },
        created: function() {
        // mounted () {
            this.suggestions = this.$store.getters.getAllUsers;
            // console.log("going to check this next: this.$store.general.state.user_data: ");
            // console.log("What is this.$store.general.state.user_data: ", this.$store.state.general.user_data);
        },
    });
});

define(['local_utools/vue'], function(Vue) {

    return Vue.extend({
        // http://fareez.info/blog/create-your-own-autocomplete-using-vuejs/
        template: '<div class="tcms_user_autocomplete">' +
        '<div style="position:relative" v-bind:class="{\'open\':openSuggestion}">' +
            '<input class="form-control" type="text" :value="value" @input="updateValue($event.target.value)"' +
                    '@keydown.enter = \'enter\'' +
                    '@keydown.down = \'down\'' +
                    '@keydown.up = \'up\'' +
                '>' +
                '<ul class="dropdown-menu utools_user_dropdown_menu">' +
                    '<li v-for="(suggestion, index) in matches"' +
                        'v-bind:class="{active: isActive(index)}"' +
                        '@click="suggestionClick(index)"' +
                    '>' +
                        '<a href="#">{{ suggestion }} </a>' +
                    '</li>' +
                '</ul>' +
            '</div>' +

        '</div>',

  /*! Copyright (c) 2016 Naufal Rabbani (http://github.com/BosNaufal)
  * Licensed Under MIT (http://opensource.org/licenses/MIT)
  *
  * Vue 2 Autocomplete @ Version 0.0.1
  *
  */

  // export default {

    props: {

      value: {
        type: String,
        required: true
      },

      suggestions: {
        type: Array,
        required: true
      }

    },

    data: function() {
      return {
        open: false,
        current: 0,
      };
    },

    computed: {
        // Filtering the suggestion based on the input
        matches: function() {
            return this.suggestions.filter(function(obj) {
                return obj.indexOf(this.value) >= 0;
            });

            // return this.suggestions.filter((obj) => {
            //     return obj.indexOf(this.value) >= 0
            // })
        },

        openSuggestion: function() {
            return this.username_selection !== '' &&
                this.matches.length !== 0 &&
                this.open === true;
        }

    },

    methods: {

        // for searching:
        // return this.suggestions.filter( ( suggestion, index ) => {
        //     const regex = new RegExp( this.value, 'gi' );
        //     return suggestion.city.match( regex );
        // });


        // Triggered the input event to cascade the updates to 
        // parent component
        updateValue: function(value) {
            if (this.open === false) {
                this.open = true;
                this.current = 0;
            }
            this.$emit('input', value);
        },

        // When enter key pressed on the input
        enter: function(event) {
            // this.$emit('input', this.matches[this.current].city)

            console.log("SMASHED THE ENTER BUTTON");
            event.preventDefault();
            this.$emit('input', this.matches[this.current]);
            this.open = false;

            // now make ajax call to fetch user's Info
            var params = {
                'call': 'getUserDetails',
                'params': {
                    'userid': this.matches[this.current],
                },
                'class': 'StudentListAjax',
            };
            this.$store.dispatch('runAJAX',{
                'params': params,
                "to_dispatch": "addStudentData"
            });
        },

        // When up arrow pressed while suggestions are open
        up: function() {
            if (this.current > 0) {
                this.current--;
            }
        },

        // When down arrow pressed while suggestions are open
        down: function() {
            // console.log("Hit the keydown, what is current: " + this.current);
            if (this.current < this.matches.length - 1) {
                this.current++;
            }
        },

        // For highlighting element
        isActive: function(index) {
            return index === this.current;
        },

        // When one of the suggestion is clicked
        suggestionClick: function(index) {
            this.$emit('input', this.matches[index]);
            this.open = false;
        }

    }
  });
});

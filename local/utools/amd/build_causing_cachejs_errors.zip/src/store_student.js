
define(['local_utools/vue'], function(Vue) {

    const state = {
        all_students: "",
        viewing_student: {
            id: 0,
            uofl_id: 'Student ID',
            username: "",
            email: "",
            
            exams: {
                '0': {
                    "label": "Select Exam",
                }
            },
        },
        
    };

    const mutations = {
        ALL_STUDENTS: function(state, payload) {
            console.log("Yay, made it to the ALL_STUDENTS");
            state.all_students = payload;
        },

        // This is for the form
        ADD_STUDENT: function(state, payload) {
        
            state.viewing_student.id = payload.user.id;
            state.viewing_student.uofl_id = payload.user.uofl_id;
            state.viewing_student.username = payload.user.username;
            state.viewing_student.email = payload.user.email;
            state.viewing_student.exams = payload.exams.data;
        //     const record = state.stocks.find(element => element.id == stockId);
        //     if (record) {
        //         record.quantity += quantity;
        //     } else {
        //         state.stocks.push({
        //             id: stockId,
        //             quantity: quantity
        //         });
        //     }
        //     state.funds -= stockPrice * quantity;
        },
        REMOVE_STUDENT: function(state, payload) {
        //     const record = state.stocks.find(element => element.id == stockId);
        //     if (record.quantity > quantity) {
        //         record.quantity -= quantity;
        //     } else {
        //         state.stocks.splice(state.stocks.indexOf(record), 1);
        //     }
        //     state.funds += stockPrice * quantity;
        },
        SET_CHANGEME: function(state, portfolio) {
        //     state.funds = portfolio.funds;
        //     state.stocks = portfolio.stockPortfolio ? portfolio.stockPortfolio : [];
        },
        ADD_SAMPLE_DATA: function(state, payload){
            // console.log("What is the payload: " + payload);
            // state.sample4 = payload;
        }
    };

    const actions = {
        removeStudent: function(context, order) {
        //     commit('SELL_STOCK', order);
        },
        addStudentData: function(context, payload) {

            console.log("STUDENT/ACTIONS -> addStudentData() -> YAY, what is payload: ", payload);
            // let's now commit
            context.commit('ADD_STUDENT', payload);
            
            // commit('ADD_STUDENT', payload);
        },
        studentCheckedIn: function(context, payload) {
            console.log("STUDENT/ACTIONS -> studentCheckedIn() -> YAY, what is payload: ", payload);
            
        },
    };

    const getters = {
        getStudentUoflID: function(state, getters) {
            return state.viewing_student.uofl_id;
        },
        getStudentUsername: function(state, getters) {
            return state.viewing_student.username;
        },
        getStudentExams: function(state, getters) {
            return state.viewing_student.exams;
        },
        sampleSet: function(state) {
          return;
        }
    };

    return {
        state: state,
        mutations: mutations,
        actions: actions,
        getters: getters
    };
});
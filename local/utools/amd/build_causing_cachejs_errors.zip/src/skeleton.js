
define([
    'local_utools/vue',
    'local_utools/side_bar',
    // 'local_utools/side_bar',
    // 'local_utools/comp_checkin'
], function(Vue, SideBar) {

    return Vue.extend({
        template: '<div class="utools_main_body">' +
            '<div class="container-fluid" id="main">' +
                '<div class="row row-offcanvas row-offcanvas-left">' +
                    '<side_bar></side_bar>' +
                    '<router-view></router-view>' +
                '</div>' +
            '</div>' +
            '<footer class="container-fluid">' +
                '<p class="text-right small">Utools</p>' +
            '</footer>' +
            '<!-- Modal -->' +
            '<div class="modal fade" id="myModal" tabindex="-1" role="dialog">' +
                '<div class="modal-dialog" role="document">' +
                    '<div class="modal-content">' +
                        '<div class="modal-header">' +
                            '<h4 class="modal-title" id="myModalLabel">Modal</h4>' +
                            '<button type="button" class="close" data-dismiss="modal" aria-label="Close">' +
                                '<span aria-hidden="true">×</span>' +
                                '<span class="sr-only">Close</span>' +
                            '</button>' +
                        '</div>' +
                        '<div class="modal-body">' +
                            '<p>This is a dashboard layout for Bootstrap 4. ' +
                            'This is an example of the Modal component which you can use to show content.' +
                            'Any content can be placed inside the modal and it can use the Bootstrap grid classes.</p>' +
                            '<p>' +
                                '<a href="https://www.codeply.com/go/KrUO8QpyXP" target="_ext">Grab the code at Codeply</a>' +
                            '</p>' +
                        '</div>' +
                        '<div class="modal-footer">' +
                            '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>' +
                            '<button type="button" class="btn btn-primary-outline" data-dismiss="modal">OK</button>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>',
        // <!-- VueJS needs a root element, so here's an empty div -->

        // <div class="row utools_main_body">

        //     <div class="col-md-2 col-1 pl-0 pr-0 collapse" :class="{show: sideBarStatus()}" id="sidebar">
        //         <side_bar></side_bar>
        //     </div>

        //     <!-- *************************************************************************** -->
        //     <!-- *************************************************************************** -->
        //     <!-- *************************************************************************** -->
        //     <div class="col-md-10 col-11 main_dash_view" v-bind:style="sideBarUpdate">
        //         <router-view></router-view>
        //     </div>
        // </div>,
        components: {
            side_bar: SideBar,
            // CheckInView: CheckInView
        },

        data: function() {
            return {
                // something_here: 'Hello and welcome to the dashboard',
            };
        },

        /**
         * Fires when the app has been mounted.
         */
        mounted: function() {
            /*
            var params = {
                'call': 'loadUsers',
                'params': {
                    'ax': true,
                    'page': 0,
                    'total': 0
                },
                'class': 'StudentListAjax',
            };
            this.$store.dispatch('runAJAX',{
                'params': params,
                "to_commit": "ALL_STUDENTS"
            });
            */
        },

        computed: {

            sideBarUpdate: function() {
                console.log("skeleton.js -> Inside sideBarUpdate");
                if (this.$store.getters.sideBarStatus == "") {
                    return {
                        'padding-left': '30px',
                        'width': '100%'
                    };
                } else {
                    return {};
                }
            }
        },

        methods: {
            // toggleLeftPanel() {
                // console.log("toggleLeftPanel -> method called to call dispatch......");
                // this.$store.dispatch('toggleLeftSidePanel');
            // },
            sideBarStatus: function() {
                console.log("skeleton.js -> going to the store to get");
                return this.$store.getters.sideBarStatus;
            }
        }

    });
});

define(['local_utools/vue'], function (Vue) {
    'use strict';

    var temp_state = {sideBarShow: "in"},
        final_state = {},
        window_stat = {};

    if (window.__SERVER__ === "true" || window.__SERVER__ === true) {
        if (typeof (window.__INITIAL_STATE__) === 'string') {
            try {
                // console.log("store_general -> What is the __INITIAL_STATE__: ", __INITIAL_STATE__);
                // console.log("store_general -> What is the __INITIAL_STATE__.table: ", __INITIAL_STATE__.table_data);
                
                window_stat = JSON.parse(window.__INITIAL_STATE__);
                final_state = Object.assign(temp_state, window_stat);
                // console.log("store_general -> What is the final state here: ", final_state);
                delete window.__INITIAL_STATE__;
                window.__SERVER__ = false;
            } catch (error) {
                console.log("ERROR, __INITIAL_STATE__ couldn't parse.");
                console.log(error);
            }
        }
    } else {
        console.log("WARNING: window.__SERVER__ was not set");
    }

    const state = final_state;
    // state.settings = {

    // }
    console.log("store_general.js -> what is final_state: ", final_state);

    const mutations = {
        TOGGLE_SIDEBAR: function(state) {
            console.log("TOGGLE_SIDEBAR -> mutations -> Yay, made it here");
            state.sideBarShow == "in" ? state.sideBarShow = "" : state.sideBarShow = "in";
            // state.sideBarShow == "bounceOutLeft" ? state.sideBarShow = "bounceOutRight" : state.sideBarShow = "bounceOutLeft";
        }
    };

    const actions = {
        toggleLeftSidePanel: function(context) {
            console.log("module_general -> Made it to the actions, going to commit to TOGGLE_SIDEBAR now");
            context.commit('TOGGLE_SIDEBAR');
        }
    };

    const getters = {
        sideBarStatus: function(state) {
            return state.sideBarShow;
        },
        getTableData: function(state) {
            return state.table_data
        },
        getAllUsers: function(state) {
            return state.user_data
        },
        getNewRelicCalls: function(state) {
            var nodes = {};
            for (var x = 0; x < state.settings.nr_server_ids.length; x++) {
                nodes[state.settings.nr_server_ids[x]] = {
                    method: 'POST',
                    url: 'https://api.newrelic.com/v2/servers/' + state.settings.nr_server_ids[x] + '.json',
                    headers: {
                        "X-Api-Key": state.settings.nr_token
                    },
                    params: {
                        'params': {
                            'id': state.settings.nr_server_ids[x],
                        },
                    },
                    // 'to_dispatch': 'addStudentData'
                }
            }
            return nodes;
            
            // return state.settings.nr_token
        },

        
    };

    return {
        state: state,
        mutations: mutations,
        actions: actions,
        getters: getters
    };
});



// getDummyData

// So in that short chat Disha and I had she was saying how Masoum is having troubles with:
// - figuring out how to do general debugging
// - can't seem to see follow logic
// - get's stuck on simple things like 'for loops'
// - seems to create more bugs 

define(['local_utools/vue'], function (Vue) {

    return Vue.extend({
        template: '<div>' +
        '<p>Settings - Cool Stuff Here........</p>' +
        '<br><br>' +
        'Reports Page.<br>' +
        '</div>',

        data: function() {
            return {
                something_here: 'Hello'
            };
        }
    });
});
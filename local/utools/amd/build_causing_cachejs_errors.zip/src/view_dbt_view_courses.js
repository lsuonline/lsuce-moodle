define(['local_utools/vue'], function (Vue) {

    return Vue.extend({
        template: '<div>' +
                '<p>DB_Tools - View All Students In A Course</p>' +
                '<ul>' +
                '<li v-for=\'link in links\'>' +
                '<a :href=\'link.url\' target="_blank">{{link.title}}</a>' +
                '</li>' +
                '</ul>' +
            '</div>',

        data: function() {
            return {
                links: [{
                        'url': 'https://vuejs.org/',
                        'title': 'Vue'
                    }, {
                        'url': 'https://router.vuejs.org/en/',
                        'title': 'Vue-router'
                    }, {
                        'url': 'https://github.com/vuejs/awesome-vue',
                        'title': 'Awesome Vue.js'
                    }, {
                        'url': 'https://twitter.com/vuejs',
                        'title': '@vuejs'
                }]
            };
        }
    });
});
define(['local_utools/vue'], function(Vue) {

    return Vue.extend({

        template: '<div class="col-xl-3 col-sm-6 py-2">' +
                '<div class="card text-white h-100" :class="stat.stat_color">' +
                    '<div class="card-body">' +
                        '<div class="rotate">' +
                            '<i :class="stat.icon"></i>' +
                        '</div>' +
                        '<h6 class="text-uppercase">{{stat.title}} {{stat.small_title}}</h6>' +
                        '<h1 :class="[{hidden: stat.hidden}, stat.block_name]">{{stat.data}}</h1>' +
                        '<div class="utools_spinner_container" :class="{hidden: !stat.hidden}">' +
                            '<div class="inner one"></div>' +
                            '<div class="inner two"></div>' +
                            '<div class="inner three"></div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
            '</div>',

            // could use these in the div card 
            // bg-success, bg-danger, bg-info, bg-warning


            // <div class="dash-card-body dash-card-flat">
            //     <div class="card" :class="stat.stat_color">
            //         <div class="card-title">
            //             <i :class="stat.icon" class="sc-f-size float-left"></i>
            //             <div class="text-uppercase font-weight-bold font-xs sc-title">{{stat.title}} {{stat.small_title}}</div>
            //         </div>
            //         <div class="card-body text-center p-3 clearfix">
            //             <div class="h5 text-info mb-0 mt-0 sc-data">{{stat.data}}</div>
            //         </div>
            //     </div>
            // </div>`,
        // v-else="stat.use_pie == true"
        //  require('../../styles/stat_card.css'),

        // components: {
        //     VueEasyPieChart: EasyPie
        // },


        props:  [
            'id',
            'stat',
            // 'key', 
            // 'wang', 
            // 'statname',
            // 'id2',

        ],
        data: function() {
            return {
                // someValueHere: 0
            };
        },

        computed: {

        },

        methods: {

        }
    });
});
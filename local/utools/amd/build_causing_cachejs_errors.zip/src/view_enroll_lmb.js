
define(['local_utools/vue'], function (Vue) {

    return Vue.extend({
        template: '<div>' +
        '<p>Enroll / LMB - Cool Stuff here......</p>' +
        '<br><br>' +
        '...<br>' +
        '</div>',

        data: function() {
            return {
                something_here: 'Hello'
            };
        }
    });
});
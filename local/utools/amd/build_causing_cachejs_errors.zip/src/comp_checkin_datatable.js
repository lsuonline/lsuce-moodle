define([
    'local_utools/vue',
    'local_utools/vuetable-ratiw',
    'local_utools/vuetable-ratiw-VuetablePagination',
    // 'local_utools/vuetable-ratiw-VuetablePaginationDropdown',
    'local_utools/vuetable-ratiw-VuetablePaginationInfo',
    // 'local_utools/vuetable-ratiw-CustomActions',
    // 'local_utools/vuetable-ratiw-FilterBar',


    // 'local_utools/vuetable-ratiw-VuetablePaginationMixin',
    // 'local_utools/vuetable-ratiw-VuetablePaginationInfoMixin',

], function (
    Vue, Vuetable,
    VuetablePagination,
    // VuetablePaginationDropDown,
    VuetablePaginationInfo
    // CustomActions,
    // FilterBar,
    // VuetablePaginationInfoMixin

) {


    // console.log("What is Vtable: ", vtable);
    // console.log("What is VuetablePagination: ", VuetablePagination);
    // api-url="https://vuetable.ratiw.net/api/users"

    return Vue.extend({
        name: 'Student-Checkin-Table',
        components: {
            Vuetable: Vuetable.default,
            VuetablePagination: VuetablePagination,
            VuetablePaginationInfo: VuetablePaginationInfo,
            // FilterBar: FilterBar,
            // CustomActions: CustomActions,
            // custom-actions: CustomActions,
            // VuetablePagination: Vuetable.default.VuetablePagination,
            // VuetablePaginationDropDown: VuetablePaginationDropDown,
            // VuetablePaginationInfo: VuetablePaginationInfo
        },

        template: '<div class="dash_checkin_table">' +
                '<div class="card">' +
                    '<div class="card-header">' +
                        '<h3>Students Checked In</h3>' +
                    '</div>' +
                    '<div class="card-body card-body-padding">' +
                        '<vuetable ref="vuetable"' +
                            ':api-url="apiUrl"' +
                            ':appendParams="appendParams"' +
                            ':fields="fields"' +
                            ':css="css.table"' +
                            'data-path="data"' +
                            'pagination-path=""' +
                            ':per-page="perPage"' +
                            ':multi-sort="multiSort"' +
                            'detail-row-component="my-details-row"' +
                            '@vuetable:cell-clicked="onCellClicked"' +
                            '@vuetable:pagination-data="onPaginationData"' +
                        '>' +
                            '<template slot-scope="props">' +
                                '<custom-actions></custom-actions>' +
                            '</template>' +
                        '</vuetable>' +
                        '<vuetable-pagination-info ref="paginationInfo"' +
                        ':css="css.pagination"' +
                        'info-class="pull-left"' +
                        '></vuetable-pagination-info>' +
                        '<vuetable-pagination ref="pagination"' +
                        ':css="css.pagination"' +
                        '@vuetable-pagination:change-page="onChangePage"' +
                        '></vuetable-pagination>' +
                    '</div>' +
                '</div>' +
            '</div>',

        // :http-options="{ headers: {Authorization: 'bearer xxx'} }" 
        /* types:
            VueTypes.any
            Validates any type of value and has no default value.

            VueTypes.array
            Validates that a prop is an array primitive.

            default: an empty array
            VueTypes.bool
            Validates boolean props.

            default: true
            VueTypes.func
            Validates that a prop is a function.

            default: an empty function
            VueTypes.number
            Validates that a prop is a number.

            default: 0
            VueTypes.integer
            Validates that a prop is an integer.

            default: 0
            VueTypes.object
            Validates that a prop is an object.

            default: an empty object
            VueTypes.string
            Validates that a prop is a string.

            default: ''
            VueTypes.symbol
            VueTypes.symbol
        */

        props: {
            apiUrl: {
                type: String,
                required: true
            },
            fields: {
                type: Array,
                required: true
            },
            sortOrder: {
                type: Array,
                'default': function() {
                    return [];
                }
            },
            appendParams: {
                type: Object,
                'default': function() {
                    return {};
                }
            },
            perPage: {
                type: Number,
                'default': function() {
                    return 50;
                }
            },
            multiSort: {
                type: Boolean,
                'default': function() {
                    return true;
                }
            },
            // detailRowComponent: {
            //     type: String,
            // },
            // css: {
            //     type: Object,
            //     default: function() {
            //         return {}
            //     }
            // }
        },
        data: function() {
            return {
                css: {
                    table: {
                        tableClass: 'table table-striped table-bordered table-hovered',
                        loadingClass: 'loading',
                        ascendingIcon: 'fa fa-chevron-up',
                        descendingIcon: 'fa fa-chevron-down',
                        handleIcon: 'fa fa-menu-hamburger',
                    },
                    pagination: {
                        infoClass: 'pull-left',
                        wrapperClass: 'vuetable-pagination pull-right',
                        activeClass: 'btn-primary',
                        disabledClass: 'disabled',
                        pageClass: 'btn btn-border',
                        linkClass: 'btn btn-border',
                        icons: {
                            first: '',
                            prev: '',
                            next: '',
                            last: '',
                        },
                    }
                },
            };
        },

        watch: {
            perPage: function(val, oldVal) {
                this.$nextTick(function() {
                    this.$refs.vuetable.refresh();
                });
            },

            paginationComponent: function(val, oldVal) {
                this.$nextTick(function() {
                    this.$refs.pagination.setPaginationData(this.$refs.vuetable.tablePagination);
                });
            }
        },

        methods: {
            /*transform (data) {
                let transformed = {}
                transformed.pagination = {
                    total: data.total,
                    per_page: data.per_page,
                    current_page: data.current_page,
                    last_page: data.last_page,
                    next_page_url: data.next_page_url,
                    prev_page_url: data.prev_page_url,
                    from: data.from,
                    to: data.to
                }

                transformed.data = []
                data = data.data
                for (let i = 0; i < data.length; i++) {
                    transformed['data'].push({
                        id: data[i].id,
                        name: data[i].name,
                        nickname: data[i].nickname,
                        email: data[i].email,
                        age: data[i].age,
                        birthdate: data[i].birthdate,
                        gender: data[i].gender,
                        address: data[i].address.line1 + ' ' + data[i].address.line2 + ' ' + data[i].address.zipcode
                    })
                }

                return transformed
            },*/

            showSettingsModal: function() {
                var self = this;
                $('#settingsModal').modal({
                    detachable: true,
                    onVisible: function() {
                        $('.ui.checkbox').checkbox();
                    }
                }).modal('show');
            },

            showLoader: function() {
                this.loading = 'loading';
            },

            hideLoader: function() {
                this.loading = '';
            },

            allCap: function(value) {
                return value.toUpperCase();
            },

            formatDate: function(value, fmt) {
                if (value === null) {
                    return '';
                }

                fmt = (typeof(fmt) === 'undefined') ? 'D MMM YYYY' : fmt;
                // return moment(value, 'YYYY-MM-DD').format(fmt)
                return value;
            },

            gender: function(value) {
                return value === 'M'
                ? '<span class="ui teal label"><i class="fa fa-male"></i>Male</span>'
                : '<span class="ui pink label"><i class="fa fa-female"></i>Female</span>';
            },

            showDetailRow: function(value) {
                console.log("ccd -> showDetailRow() -> START");
                var icon = this.$refs.vuetable.isVisibleDetailRow(value) ? 'down' : 'right';
                return [
                '<a class="show-detail-row">',
                '<i class="fa fa-chevron-circle ' + icon + ' icon"></i>',
                '</a>'
                ].join('');
            },

            setFilter: function() {
                this.moreParams['filter'] = this.searchFor;
                this.$nextTick(function() {
                    this.$refs.vuetable.refresh();
                });
            },

            resetFilter: function() {
                this.searchFor = '';
                this.setFilter();
            },
            // next 2 funcs are from tutorial 16
            onFilterSet: function(filterText) {
                this.appendParams.filter = filterText;
                Vue.nextTick(function() {
                    this.$refs.vuetable.refresh();
                });
            },
            onFilterReset: function() {
                delete this.appendParams.filter;
                Vue.nextTick(function() {
                    this.$refs.vuetable.refresh();
                });
            },

            preg_quote: function( str ) {
                // http://kevin.vanzonneveld.net
                // +   original by: booeyOH
                // +   improved by: Ates Goral (http://magnetiq.com)
                // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
                // +   bugfixed by: Onno Marsman
                // *     example 1: preg_quote("$40");
                // *     returns 1: '\$40'
                // *     example 2: preg_quote("*RRRING* Hello?");
                // *     returns 2: '\*RRRING\* Hello\?'
                // *     example 3: preg_quote("\\.+*?[^]$(){}=!<>|:");
                // *     returns 3: '\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:'

                return (str+'').replace(/([\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:])/g, "\\$1");
            },

            highlight: function(needle, haystack) {
                return haystack.replace(
                new RegExp('(' + this.preg_quote(needle) + ')', 'ig'),
                    '<span class="highlight">$1</span>'
                );
            },

            rowClassCB: function(data, index) {
                return (index % 2) === 0 ? 'odd' : 'even';
            },
            //
            // Example of defining queryParams as a function
            //
            // queryParams (sortOrder, currentPage, perPage) {
            //   return {
            //     'sort': sortOrder[0].field + '|' + sortOrder[0].direction,
            //     'order': sortOrder[0].direction,
            //     'page': currentPage,
            //     'per_page': perPage
            //   }
            // },

            onCellClicked: function(data, field, event) {
                console.log('ccd -> onCellClicked() -> cellClicked', field.name);
                if (field.name !== '__actions') {
                    this.$refs.vuetable.toggleDetailRow(data.id);
                }
            },

            onCellDoubleClicked: function(data, field, event) {
                console.log('cellDoubleClicked:', field.name);
            },

            onCellRightClicked: function(data, field, event) {
                console.log('cellRightClicked:', field.name);
            },

            onLoadSuccess: function(response) {
                // set pagination data to pagination-info component
                console.log("onLoadSuccess suckasssssss");
                this.$refs.paginationInfo.setPaginationData(response.data);

                var data = response.data.data;
                if (this.searchFor !== '') {
                    for (var n in data) {
                        data[n].name = this.highlight(this.searchFor, data[n].name);
                        data[n].email = this.highlight(this.searchFor, data[n].email);
                    }
                }
            },

            onLoadError: function(response) {
                if (response.status == 400) {
                    console.log('Something\'s Wrong!', response.data.message, 'error');
                } else {
                    console.log('Oops, error');
                }
            },

            onPaginationData: function(tablePagination) {
                this.$refs.paginationInfo.setPaginationData(tablePagination);
                this.$refs.pagination.setPaginationData(tablePagination);
            },

            onChangePage: function(page) {
                this.$refs.vuetable.changePage(page);
            },

            onInitialized: function(fields) {
                console.log('onInitialized', fields);
                this.vuetableFields = fields;
            },

            onDataReset: function() {
                console.log('onDataReset');
                this.$refs.paginationInfo.resetData();
                this.$refs.pagination.resetData();
            },
        }
    });
});
        /*
        ========================================================
        ========================================================
        SLOT WAY
        ========================================================
        ========================================================

        props: {
            apiUrl: {
                type: String,
                required: true
            },
            fields: {
                type: Array,
                required: true
            },
            sortOrder: {
                type: Array,
                default() {
                    return []
                }
            },
            appendParams: {
                type: Object,
                default() {
                    return {}
                }
            },
            detailRowComponent: {
                type: String
            }
        },
        data () {
            return {
            }
        },
        mounted: function () {
            // this gives an error with $on
            // this.$events.$on('filter-set', eventData => this.onFilterSet(eventData))
            // this.$events.$on('filter-reset', e => this.onFilterReset())
        },

        render(h) {
            console.log("render called.....");

            return h(
                'div', 
                {
                    class: { ui: true, container: true }
                },
                [
                    h('filter-bar'),
                    this.renderVuetable(h),
                    this.renderPagination(h)
                ]
            )
        },

        methods: {
            // render related functions
            renderVuetable(h) {
                return h(
                    'vuetable', { 
                        ref: 'vuetable',
                        props: {
                            apiUrl: this.apiUrl,
                            fields: this.fields,
                            paginationPath: "",
                            perPage: 10,
                            multiSort: true,
                            sortOrder: this.sortOrder,
                            appendParams: this.appendParams,
                            detailRowComponent: this.detailRowComponent,
                        },
                        on: {
                            'vuetable:cell-clicked': this.onCellClicked,
                            'vuetable:pagination-data': this.onPaginationData,
                        },
                        scopedSlots: this.$vnode.data.scopedSlots
                    }
                )
            },
            renderPagination(h) {
                console.log("renderPagination called.....");
                // , {'css': 'css.pagination'}
                var poopy = h(
                    'div',
                    { class: {'vuetable-pagination': true, 'ui': true, 'basic': true, 'segment': true, 'grid': true} },
                    [
                        h('vuetable-pagination-info', { ref: 'paginationInfo' }),
                        h('vuetable-pagination', {
                            ref: 'pagination',
                            on: {
                                'vuetable-pagination:change-page': this.onChangePage
                            },
                        })
                    ]
                )
                return poopy;
            },
            // ------------------
            allcap (value) {
                return value.toUpperCase()
            },
            genderLabel (value) {
                console.log("genderLabel called.....");
                return value === 'M'
                ? '<span class="ui teal label"><i class="fa fa-male"></i>Male</span>'
                : '<span class="ui pink label"><i class="fa fa-female"></i>Female</span>'
            },
            formatNumber (value) {
                // return accounting.formatNumber(value, 2)
                return value
            },
            formatDate (value, fmt = 'D MMM YYYY') {
                // return (value == null)
                // ? ''
                // : moment(value, 'YYYY-MM-DD').format(fmt)
                return value
            },
            onPaginationData (paginationData) {
                this.$refs.pagination.setPaginationData(paginationData)
                this.$refs.paginationInfo.setPaginationData(paginationData)
            },
            onChangePage (page) {
                this.$refs.vuetable.changePage(page)
            },
            onCellClicked (data, field, event) {
                console.log('cellClicked: ', field.name)
                this.$refs.vuetable.toggleDetailRow(data.id)
            },
            onFilterSet (filterText) {
                this.appendParams.filter = filterText
                Vue.nextTick( () => this.$refs.vuetable.refresh() )
            },
            onFilterReset () {
                delete this.appendParams.filter
                Vue.nextTick( () => this.$refs.vuetable.refresh() )
            }
        }
        

        data: function () {
            return {
                /*apiUrl: "/local/utools/lib/ajax.php",
                loading: '',
                searchFor: '',
                moreParams: {
                    'call': 'getCheckedInStudentsTest',
                    'class': 'StudentListAjax',
                    // 'params': {
                    //     'spunky': 'cookies',
                    //     'page': '0',
                    //     'total': '0'
                    // },
                },
                // fields: tableColumns,
                tableHeight: '600px',
                // multi-sort-key: "ctrl",
                // vuetableFields: false,
                sortOrder: [{
                    field: 'name',
                    direction: 'asc',
                }],
                multiSort: true,
                paginationComponent: 'vuetable-pagination',
                perPage: 100,
                paginationInfoTemplate: 'Showing record: {from} to {to} from {total} item(s)',
                

                // lang: {
                //     'nickname': 'Nickname',
                //     'birthdate': 'Birthdate',
                // },
                fields: [{ 
                    name: '__handle',
                    titleClass: 'center aligned',
                    dataClass: 'center aligned'
                
                }, {
                    name: '__sequence',
                    title: 'No.',
                    titleClass: 'center aligned',
                    dataClass: 'right aligned'
                    // width: '50px'
                
                }, {
                    name: '__checkbox',
                    // width: '30px',
                    title: 'checkbox',
                    titleClass: 'center aligned',
                    dataClass: 'center aligned'
                
                // }, {
                //     name: 'id',
                //     title: '<i class="fa fa-list-ul"></i> Detail',
                //     dataClass: 'center aligned',
                //     width: '100px',
                //     callback: 'showDetailRow'

                
                }, {
                    name: 'name',
                    title: '<i class="fa fa-address-card-o"></i> Full Name',
                    sortField: 'name',
                    width: '150px'
                
                }, {
                    name: 'email',
                    title: '<i class="fa fa-envelope-o"></i> Email',
                    sortField: 'email',
                    width: '200px',
                    dataClass: "vuetable-clip-text",
                    visible: true

                // }, {
                //     name: 'course',
                //     title: '<i class="fa fa-envelope-o"></i> Course',
                //     sortField: 'course',
                //     width: '200px',
                //     dataClass: "vuetable-clip-text",
                //     visible: true
                
                // }, {
                //     name: 'nickname',
                //     title: (nameOnly = false) => {
                //         return `<i class="fa fa-hand-spock-o"></i> Nickname`
                //         // nameOnly
                //         // ? lang['nickname']
                //         // : 
                //     },
                //     sortField: 'nickname',
                //     callback: 'allCap',
                //     width: '120px'
                
                // }, {
                //     name: 'birthdate',
                //     title: (nameOnly = false) => {
                //         return `<i class="fa fa-hand-spock-o"></i> Birthdate`
                //         // return nameOnly
                //         // ? lang['birthdate']
                //         // : `<i class="fa fa-hand-spock-o"></i> ${lang['birthdate']}`
                //     },
                //     sortField: 'birthdate',
                //     width: '100px',
                //     callback: 'formatDate|D/MM/Y'
               
                }, {
                    name: 'gender',
                    title: 'Gender',
                    sortField: 'gender',
                    titleClass: 'center aligned',
                    dataClass: 'center aligned',
                    callback: 'gender',
                    width: '100px',
               
                }, {
                    name: '__component:custom-actions',
                    title: 'Actions',
                    titleClass: 'center aligned',
                    dataClass: 'center aligned',
                    width: '150px'
                }],

                css: {
                    table: {
                        tableClass: 'table table-striped table-bordered table-hovered',
                        loadingClass: 'loading',
                        ascendingIcon: 'fa fa-chevron-up',
                        descendingIcon: 'fa fa-chevron-down',
                        handleIcon: 'fa fa-menu-hamburger',
                    },
                    pagination: {
                        infoClass: 'pull-left',
                        wrapperClass: 'vuetable-pagination pull-right',
                        activeClass: 'btn-primary',
                        disabledClass: 'disabled',
                        pageClass: 'btn btn-border',
                        linkClass: 'btn btn-border',
                        icons: {
                            first: '',
                            prev: '',
                            next: '',
                            last: '',
                        },
                    }
                },
                sortOrder: [{
                    field: 'email',
                    sortField: 'email',
                    direction: 'asc'
                }],
                moreParams: {}
            };
        },
        */

/* Sample JSON data for this to work:

{  
   "total":200,
   "per_page":15,
   "current_page":1,
   "last_page":14,
   "next_page_url":"https:\/\/vuetable.ratiw.net\/api\/users?page=2",
   "prev_page_url":null,
   "from":1,
   "to":15,
   "data":[  
      {  
         "id":1,
         "name":"Noelia O'Kon",
         "nickname":"asperiores",
         "email":"otho.smitham@example.com",
         "birthdate":"1978-06-28 00:00:00",
         "gender":"F",
         "salary":"13098.00",
         "group_id":2,
         "created_at":"2017-01-01 07:21:10",
         "updated_at":"2017-01-01 07:21:10",
         "age":39,
         "group":{  
            "id":2,
            "name":"Exec",
            "description":"Executives"
         },
         "address":{  
            "id":1,
            "user_id":1,
            "line1":"0888 Aniyah Locks\nLake Bridie, NJ 51086",
            "line2":"Cayman Islands",
            "zipcode":"92991-2805",
            "mobile":"1-742-816-9238x848",
            "fax":"(484)438-4697x8638"
         }
      },
      {  
         "id":2,
         "name":"Mr. Enid Von PhD",
         "nickname":"alias",
         "email":"pollich.cecilia@example.com",
         "birthdate":"1990-09-18 00:00:00",
         "gender":"M",
         "salary":"35978.00",
         "group_id":4,
         "created_at":"2017-01-01 07:21:10",
         "updated_at":"2017-01-01 07:21:10",
         "age":27,
         "group":{  
            "id":4,
            "name":"Sup",
            "description":"Supervisors"
         },
         "address":{  
            "id":2,
            "user_id":2,
            "line1":"59732 Iva Spur Suite 468\nEast Hortenseton, VA 70087",
            "line2":"Cayman Islands",
            "zipcode":"41967",
            "mobile":"1-913-407-7558x503",
            "fax":"(388)906-8002"
         }
      },

*/
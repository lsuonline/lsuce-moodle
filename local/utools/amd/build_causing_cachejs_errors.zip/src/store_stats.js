
define(['local_utools/vue', 'local_utools/axios'], function(Vue, axios) {

    // stat_charcoal
    // stat_green
    // stat_purple
    // stat_orange
    // stat_teal
    const state = {
        piwik_data: {},
        flat_blocks: {
            'piwik_user_count': {
                title: "Moodle",
                small_title: "Users",
                data: 99,
                icon: "fa fa-users fa-4x",
                stat_color: "stat_blue",
                block_name: 'piwik_user_count',
                hidden: true,
            }, 
            'piwik_max_users_stat': {
                title: "Max Users",
                small_title: "Today",
                data: 99,
                icon: "fa fa-pencil-square-o fa-4x",
                stat_color: "stat_salmon",
                block_name: 'piwik_max_users_stat',
                hidden: true,
            },
            'tcms_user_count': {
                title: "Students",
                small_title: "Test Centre",
                data: 99,
                icon: "fa fa-calendar fa-4x",
                stat_color: "stat_yellow",
                block_name: 'tcms_user_count',
                hidden: true,
            }
        },

        /*flat_blocks: [{
            title: "Moodle",
            small_title: "Users",
            data: 47,
            icon: "fa fa-users fa-4x",
            stat_color: "stat_blue"
        }, {
            title: "Max Users",
            small_title: "Today",
            data: 567,
            icon: "fa fa-pencil-square-o fa-4x",
            stat_color: "stat_salmon"
        }, {
            title: "Students",
            small_title: "Test Centre",
            data: 12,
            icon: "fa fa-calendar fa-4x",
            stat_color: "stat_yellow"
        },
        ],
        */
        // {
        //     title: "Written",
        //     small_title: "Semester",
        //     data: 5748,
        //     icon: "fa fa-pencil-square-o",
        //     stat_color: "stat_lightblue",
        // },
        // {
        //     title: "Max Student",
        //     small_title: "Estimation",
        //     data: 5748,
        //     icon: "fa fa-pencil-square-o",
        //     stat_color: "stat_lightblue"
        // }
        pie_blocks: [{
            block: 0,
            data: {
                title: "Sleepy",
                small_title: "CPU",
                data: 99,
                icon: "fa fa-dashboard",
                stat_color: "stat_charcoal",
                pie_block_num: 0
            }
        }, {
            block: 1,
            data: {
                title: "Sneezy",
                small_title: "CPU",
                data: 99,
                icon: "fa fa-dashboard",
                stat_color: "stat_charcoal",
                pie_block_num: 1
            }
        }, {
            block: 2,
            data: {
                title: "Sleepy",
                small_title: "Memory",
                data: 99,
                icon: "fa fa-dashboard",
                stat_color: "stat_purple",
                pie_block_num: 2
            }
        }, {
            block: 3,
            data: {
                title: "Sneezy",
                small_title: "Memory",
                data: 99,
                icon: "fa fa-dashboard",
                stat_color: "stat_purple",
                pie_block_num: 3
            }
        }],
    };

    const mutations = {
        STAT_SAMPLE_DATA: function(state, payload){
            console.log("What is the payload: " + payload);
        },
        CHANGE_PIE_BLOCK: function(state, payload){
            // To find an object
            // let obj = arr.find(o => o.name === 'string 1');

            // To change an object
            // console.log("pie_blocks BEFORE: ", state.pie_blocks);

            var obj = state.pie_blocks.find(function(o, i) {
                if (o.block === payload.pie_index) {
                    // state.pie_blocks[i].data.data = { name: 'new string', value: 'this', other: 'that' };
                    state.pie_blocks[i].data.data = payload.val;
                    return true; // stop searching
                }
            });

            // console.log("pie_blocks AFTER: ", state.pie_blocks);
        },
        UPDATE_PIWIK_USER_STAT: function(state, payload) {
            // console.log("MUTATION -> **************************************");
            // console.log("MUTATION -> **************************************");
            // console.log("MUTATION -> **************************************");
            // console.log("MUTATION -> UPDATE_PIWIK_USER_STAT -> going to update the piwik stat, what is payload: ", payload);
            // if (state.flat_blocks[0].piwik_user_count.data)
            state.flat_blocks.piwik_user_count.data = payload;
            state.flat_blocks.piwik_user_count.hidden = false;
        },
        UPDATE_PIWIK_MAX_USER_STAT: function(state, payload) {
            // console.log("MUTATION -> UPDATE_PIWIK_MAX_USER_STAT -> going to update the piwik stat, what is payload: ", payload);
            state.flat_blocks.piwik_max_users_stat.data = payload;
            state.flat_blocks.piwik_max_users_stat.hidden = false;
        },
        UPDATE_TCMS_USER_STAT: function(state, payload) {
            console.log("MUTATION -> UPDATE_TCMS_USER_STAT -> TCMS count is: " + payload);
            state.flat_blocks.tcms_user_count.data = payload;
            state.flat_blocks.tcms_user_count.hidden = false;

        }
    };

    const actions = {
        
        statSampleData: function(context, payload) {
            context.commit('STAT_SAMPLE_DATA', payload);
        },
        fetchData: function(context, payload) {
            //context.commit('STAT_SAMPLE_DATA', payload);
            // console.log("Going to fetch via axios");
            axios({
                method: 'post',
                url: 'lib/ajax.php',
                data: {
                    firstName: 'Fred',
                    lastName: 'Flintstone'
                }
            });
        },
        changePieBlock: function(context, payload) {
            context.commit('CHANGE_PIE_BLOCK', payload);
        },
        updateStatBlock: function(context, payload) {
            // piwik_user_count
            // piwik_max_users_stat
            // tcms_user_count
            // if (payload)
        },

        updatePiwikMaxUserStat: function(context, payload) {
            console.log("ACTION -> piwik stat, what is payload: ", payload);
            var highest_count = 0;
            for (var x in payload) {
                if (payload[x].nb_uniq_visitors > highest_count) {
                    highest_count = payload[x].nb_uniq_visitors;
                }
            }
            // payload is an array of objects.....which only has one object
            // if (payload[0].visitors != undefined) {
                context.commit('UPDATE_PIWIK_MAX_USER_STAT', highest_count);
            // }
        },
        updatePiwikUserStat: function(context, payload) {
            // console.log("ACTION -> piwik stat, what is payload: ", payload);
            // payload is an array of objects.....which only has one object
            if (payload[0].visitors != undefined) {
                context.commit('UPDATE_PIWIK_USER_STAT', payload[0].visitors);
            }
        },
        updateTCMSUserStat: function(context, payload) {
            console.log("ACTION -> TCMS stat, what is payload: ", payload);
            if (payload.count != undefined) {
                context.commit('UPDATE_TCMS_USER_STAT', payload.count);
            }  
        },
    };

    const getters = {
        getFlatStats: function(state, getters) {
            // console.log("module_stats -> Yay, made it this far......what is state: ", state.blocks);
            return state.flat_blocks;
        },
        getPieStats: function(state, getters) {
            // console.log("module_stats -> Yay, made it this far......what is state: ", state.blocks);
            return state.pie_blocks;
        },
        getPiwikData: function(state) {
            // {'module':'API','idSite':1,'method':'Live.getCounters','lastMinutes':30,'format':'JSON','token_auth':'0c1c48ff5d224469767df3ec5264e479'}

            var piwik_call1 = {
                'module': 'API',
                'idSite': '1',
                'method': 'Live.getCounters',
                'lastMinutes': 30,
                'format': 'JSON',
                'token_auth': '0c1c48ff5d224469767df3ec5264e479',
            }, piwik_call2 = {
                'module': 'API',
                'idSite': '1',
                'method': 'VisitTime.getVisitInformationPerLocalTime',
                'format': 'JSON',
                'period': 'day',
                'date': 'today',
                'token_auth': '0c1c48ff5d224469767df3ec5264e479',
            };

            var piwik_data = [{
                method: 'GET',
                url: 'https://analytics.uleth.ca/index.php',
                data: piwik_call1,
                dataType: "jsonp",
                to_dispatch: "updatePiwikUserStat",
                block_name: "piwik_user_count"
            }, {
                method: 'GET',
                url: 'https://analytics.uleth.ca/index.php',
                data: piwik_call2,
                dataType: "jsonp",
                to_dispatch: "updatePiwikMaxUserStat",
                block_name: "piwik_max_users_stat"

            }];

            // ========================================================
            /*
            piwik_objects: {

                visitorBrowser: {
                    method: 'VisitTime.getVisitInformationPerLocalTime',
                    dataTitle: [ "nb_uniq_visitors", "nb_visits", "nb_actions", "nb_users", "max_actions", "sum_visit_length", "bounce_count", "nb_visits_converted"],
                    htmlTag: '#piwik_stats_tab1',
                    apiCall: 'visitorBrowser',
                    visual: 'area',
                    xAxisName: ' time'

                },
                browserInfo: {
                    method: 'UserSettings.getBrowserVersion',
                    dataTitle: ['label', 'nb_uniq_visitors', 'nb_visits', 'nb_actions', 'max_actions', 'sum_visit_length', 'bounce_count', 'nb_visits_converted', 'logo', 'shortLabel'],
                    htmlTag: '#piwik_stats_tab3',
                    apiCall: 'browserInfo',
                    visual: 'pie'
                },
                referrerWebsites: {
                    widgetName: 'Referrer Websites',
                    method: 'Referrers.getWebsites',
                    dataTitle: ['label', 'nb_uniq_visitors', 'nb_visits', 'nb_actions', 'max_actions', 'sum_visit_length', 'bounce_count', 'nb_visits_converted', 'logo', 'shortLabel'],
                    htmlTag: '#piwik_stats_tab2',
                    apiCall: 'referrerWebsites',
                    visual: 'bar'
                },
                currentUser: {
                    widgetName: 'current User',
                    method: 'Live.getCounters',
                    dataTitle: ["visits", "actions", "visitors", "visitsConverted"],
                    htmlTag: '#piwik_current_user_num',
                    apiCall: 'currentUser',
                    visual: 'micro'
                }
            },
            */

            return piwik_data;
        }
    };

    return {
        state: state,
        mutations: mutations,
        actions: actions,
        getters: getters
    };
});

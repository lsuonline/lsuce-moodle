define(['local_utools/vue', 'local_utools/axios', 'jquery'], function (Vue, Axios, $) {

    // takes a {} object and returns a FormData object
    var objectToFormData = function(obj, form, namespace) {

        var fd = form || new FormData();
        var formKey;

        for (var property in obj) {
            if (obj.hasOwnProperty(property)) {

                if (namespace) {
                    formKey = namespace + '[' + property + ']';
                } else {
                    formKey = property;
                }

                // if the property is an object, but not a File,
                // use recursivity.
                if (typeof obj[property] === 'object' && !(obj[property] instanceof File)) {
                    objectToFormData(obj[property], fd, property);
                } else {
                    // if it's a string or a File object
                    fd.append(formKey, obj[property]);
                }
            }
        }
        return fd;
    };

    // ====================================================================================
    // ====================================================================================
    // ====================================================================================
    return {

        runAJAX: function(commit, payload) {
            /*
                The AJAX call must follow the follow format for it to work:
                var params = {
                    'call': 'getCurrentStudentCount',
                    'xtra_data': {
                        'ax': true,
                        'page': 0,
                        'total': 0
                    },
                    'class': 'TcmsAjax',
                    "to_dispatch": "updateTCMSUserStat"
                };
            */
            var to_dispatch = payload.params.to_dispatch,
                block_name = payload.params.block_name;
            payload = objectToFormData(payload);

            Axios({
                method: 'post',
                url: 'lib/ajax.php',
                data: payload,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                // config: {
                //     to_dispatch: to_dispatch
                // },
                params: {
                    to_dispatch: to_dispatch,
                    block_name: block_name
                },

            }).then(function(response) {
                // return response;
                // var to_dispatch = '';

                try {
                    to_dispatch = (JSON.parse(response.config.data)).params.to_dispatch;
                    block_name = (JSON.parse(response.config.data)).params.block_name;
                } catch (err) {
                    console.log("AXIOS -> AJAX -> CATCH ERROR");
                }

                // console.log("AXIOS -> AJAX -> SUCCESS");
                // console.log("AXIOS -> AJAX -> response.data: ", response.data);
                // console.log("AXIOS -> AJAX -> response.status: ", response.status);
                // console.log("AXIOS -> AJAX -> response.statusText: ", response.statusText);
                // console.log("AXIOS -> AJAX -> response.headers: ", response.headers);
                // console.log("AXIOS -> AJAX -> response.config: ", response.config);

                if (response.data.error) {
                    console.log('DATA FAIL', response.data.error);
                } else {
                    // this.postStatus = true
                    if (response.data.success == true || response.data.success == "true") {
                        that.$store.dispatch(response.config.params.to_dispatch, response.data.data);
                    } else {
                        console.log('BACKEND RETURNED FAIL', response.data.message);
                    }
                }
            });
        },

        runAJAXExternal: function(commit, payload) {
            var da_store = this;
            var jaxy = $.ajax(payload).promise();

            jaxy.then(function (data) {
                console.log("jQuery -> AJAX -> SUCCESS -> data is: ", data);
                da_store.dispatch(this.to_dispatch, data);
            });
        },
    };
});
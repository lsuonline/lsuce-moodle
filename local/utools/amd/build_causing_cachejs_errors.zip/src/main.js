requirejs.config({
    // baseUrl: "", // this breaks it

    paths: {
        // 'vue': 'local_utools/vue',
        // 'vue-easytable': '/local/utools/amd_not/vue-easytable',
        // 'vue-easytable': '/local/utools/js/vue-easytable',
        // 'vue-easytable': '/local/utools/amd_not/vue-easytable_converted',
        // 'vue-router': 'local_utools/vue-router',
        // 'axios': 'local_utools/axios',
        // 'routes': 'local_utools/routes',
        // 'moment': 'local_utools/moment',
        // 'fullcalendar': 'local_utools/fullcalendar'
    },

    shim: {
        // vue: {
        //     exports: 'Vue'
        // },
        // vue_router: {
        //     exports: 'VueRouter'
        // },
        // routes: {
        //     exports: 'routes'
        // },
        // moment: {
        //     exports: 'moment'
        // },
        // fullcalendar: {
        //     deps: ['jquery', 'moment'],
        //     exports: 'fullcalendar'
        // }
        // 'vue-easytable': {
            // deps: ['local_utools/vue'],
            // exports: 'vue-easytable'
        // }
    }
});

// console.log("main js file is now going to be loaded");
// Libraries used in this Dashboard are:
// Fullcalendar: https://fullcalendar.io/
// Moment: https://momentjs.com/
// Datatable: https://github.com/ratiw/vuetable-2-tutorial/wiki/lesson-01

// possible fix for shim: https://docs.exoplatform.org/public/index.jsp?topic=%2FPLF43%2FPLFDevGuide.JavaScript.Shim_and_NonAMD.html

// in case vue-datatable-component doesn't work: https://www.npmjs.com/package/vue-datatables

define([
    'local_utools/vue',
    'local_utools/vue-router',
    'local_utools/routes',
    'local_utools/info_bar',
    'local_utools/skeleton',
    'local_utools/store',
    'local_utools/axios',
    'local_utools/heartbeat',

    // 'local_utools/vuetable-ratiw-CustomActions',
    // 'local_utools/vuetable-ratiw-FilterBar',
    // 'local_utools/vuetable-ratiw-SettingsModal',
    // 'local_utools/vuetable-ratiw-MyDetailsRow',

    // 'vue-easytable',
// ], function (Vue, VueRouter, AppRoutes, Bar, Side, Store, Axios, Datatable) {
], function (Vue, VueRouter, AppRoutes, Bar, Skeleton, Store, Axios, HB) {
        'use strict';
        // console.log("Main.JS -> Starting up App......");
        return {

            init: function (extras) {
                // extras is a simple bool for if the user is admin or not
                Vue.use(VueRouter);
                // Vue.use(Datatable);

                // Vue.component('vtable', vtable);
                // Vue.component(vPagination, vPagination)

                var router = new VueRouter({
                    mode: 'history',
                    routes: AppRoutes
                });

                // Register any components that need to be done globally
                // Vue.component('custom-actions', CustomActions);
                // Vue.component('filter-bar', FilterBar);
                // Vue.component('settings-modal', SettingsModal);
                // Vue.component('my-details-row', MyDetailsRow);

                // If there is any data coming from __INITIAL_STATE__ 
                // then it'll be injected into the module_general store
                new Vue({
                    el: '#utools_app',
                    router: router,
                    store: Store,
                    data: {
                        is_admin: extras
                    },
                    components: {
                        // note ** info bar and skeleton are loaded from the main.mustache template.
                        info_bar: Bar,
                        skeleton: Skeleton
                    }
                });
                // this starts the heart beat so ajax calls will be made every (currently hard coded to) 30 seconds
                HB.start();
            }
        };
    }
);

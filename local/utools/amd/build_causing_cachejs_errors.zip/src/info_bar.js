define(['local_utools/vue'], function(Vue) {

    return Vue.extend({
        template:
            '<nav class="navbar navbar-expand-md navbar-dark bg-primary mb-3" id="utools_main_nav_bar">' +
                '<div class="flex-row d-flex">' +
                    '<button type="button" class="navbar-toggler mr-2 " data-toggle="offcanvas" title="Toggle Dashboard">' +
                        '<span class="navbar-toggler-icon"></span>' +
                    '</button>' +
                    '<a class="navbar-brand" href="#" title="Utools Dashboard">Utools Dashboard</a>' +
                '</div>' +
                '<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsingNavbar">' +
                    '<span class="navbar-toggler-icon"></span>' +
                '</button>' +
                '<div class="navbar-collapse collapse" id="collapsingNavbar">' +
                    '<ul class="navbar-nav">' +
                        '<!-- <li class="nav-item active">' +
                            '<a class="nav-link" href="#">Home <span class="sr-only">Home</span></a>' +
                        '</li>' +
                        '<li class="nav-item">' +
                            '<a class="nav-link" href="//www.codeply.com">Link</a>' +
                        '</li> -->' +
                    '</ul>' +
                    '<ul class="navbar-nav ml-auto">' +
                        '<li class="nav-item">' +
                            '<a class="nav-link" href="#myAlert" data-toggle="collapse">Alert</a>' +
                        '</li>' +
                        '<!-- <li class="nav-item">' +
                            '<a class="nav-link" href="" data-target="#myModal" data-toggle="modal">About</a>' +
                        '</li> -->' +
                    '</ul>' +
                '</div>' +
            '</nav>',
        // <div class="utools_info_bar">
        //                 <ul class="nav">
        //                     <button class="utools-sidebar-toggle" @click="toggleLeftPanel">
        //                         <i class="fa fa-arrow-right"></i>
        //                     </button>
        //                     <button class="utools_info_bar_icons ml-auto">
        //                         <i class="fa fa-bell-o"></i>
        //                     </button>
        //                 </ul>
        //             </div>
        //         `,
        data: function() {
            return {

            };
        },
        methods: {
            toggleLeftPanel: function() {
                console.log("toggleLeftPanel -> method called to call dispatch......");
                this.$store.dispatch('toggleLeftSidePanel');
            }
        }
    });
});

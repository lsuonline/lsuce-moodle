
define([
    'local_utools/view_dashboard',
    'local_utools/view_reporting',
    'local_utools/view_enroll_lmb',
    'local_utools/view_stats',
    'local_utools/view_passwords',

    'local_utools/view_lmb_live_logs',
    'local_utools/view_lmb_dead_enroll',
    'local_utools/view_lmb_unenroll',
    'local_utools/view_lmb_banner_compare',
    // 'local_utools/view_dbt',
    'local_utools/view_dbt_missing_id',
    'local_utools/view_dbt_course_restore',
    'local_utools/view_dbt_mass_enroll',
    'local_utools/view_dbt_view_courses',
    'local_utools/view_logs',
    'local_utools/view_settings',

], function (
    Dashboard,
    Reporting,
    Enroll_LMB,
    Stats,
    Passwords,
    Live_Logs,
    Dead_Enroll,
    Unenroll,
    Banner_Compare,
    DB_Tools,
    Missing_ID,
    Course_Restore,
    Mass_Enroll,
    View_Courses,
    Logs,
    Settings
) {
    'use strict';
    return [
        {
            // path: '/',
            path: '/local/utools/index.php',
            component: Dashboard,
            redirect: '/local/utools/dashboard'
        },
        {
            // path: '/',
            path: '/local/utools/',
            component: Dashboard,
            redirect: '/local/utools/dashboard'
        },
        {
            // path: '/',
            path: '/local/utools/dashboard',
            name: 'dashboard',
            component: Dashboard
        },
        {
            // path: '/links',
            path: '/local/utools/enrol_lmb',
            name: 'enroll_lmb',
            component: Enroll_LMB
        },
        {
            path: '/local/utools/reporting',
            name: 'reporting',
            component: Reporting
        },
        {
            path: '/local/utools/stats',
            name: 'stats',
            component: Stats
        },
        {
            path: '/local/utools/passwords',
            name: 'passwords',
            component: Passwords
        },
        // -----------------------------------------
        {
            path: '/local/utools/live_logs',
            name: 'live_logs',
            component: Live_Logs
        },
        {
            path: '/local/utools/dead_enroll',
            name: 'dead_enroll',
            component: Dead_Enroll
        },
        {
            path: '/local/utools/unenroll',
            name: 'unenroll',
            component: Unenroll
        },
        {
            path: '/local/utools/banner_compare',
            name: 'banner_compare',
            component: Banner_Compare
        },

        // -----------------------------------------


        {
            path: '/local/utools/db_tools',
            name: 'db_tools',
            redirect: '/local/utools/view_courses'
            // component: Missing_ID
        },
        {
            path: '/local/utools/view_courses',
            name: 'view_courses',
            component: View_Courses
        },
        {
            path: '/local/utools/missing_id',
            name: 'missing_id',
            component: Missing_ID
        },
        {
            path: '/local/utools/course_restore',
            name: 'course_restore',
            component: Course_Restore
        },
        {
            path: '/local/utools/mass_enroll',
            name: 'mass_enroll',
            component: Mass_Enroll
        },

        // {
        //     path: '/local/utools/db_tools/:sub_db',
        //     component: DB_Tools,
        //     name: 'db_tools',
        //     redirect: '/local/utools/db_tools/missing_id',
        //     children: [
        //       {
        //         // path: '/local/utools/db_tools/missing_id',
        //         path: 'missing_id',
        //         name: 'Missing Id\'s',
        //         component: 
        //       },
        //       {
        //         // path: '/local/utools/db_tools/courserestore',
        //         path: 'courserestore',
        //         name: 'Course Restore',
        //         component: 
        //       },
        //       {
        //         path: '/local/utools/db_tools/massenroll',
        //         name: 'Mass Enroll',
        //         component: 
        //       },
        //       {
        //         path: '/local/utools/db_tools/view_courses',
        //         name: 'View Courses',
        //         component: 
        //       },
        //     ]


            // path: '/admin',
            // component: MarketLayout,
            // redirect: '/admin/overview',
            // meta: {
            //   auth: true,
            // },
            // children: [
            //   {
            //     path: 'overview',
            //     name: 'Overview',
            //     component: Overview
            //   },
              // {
        // },

        {
            path: '/local/utools/logs',
            component: Logs
        },
        {
            path: '/local/utools/settings',
            beforeEnter: function() {
                location.href = window.location.origin + '/admin/settings.php?section=local_utools';
            }
            // Fcomponent: Settings
        },

    ];
});
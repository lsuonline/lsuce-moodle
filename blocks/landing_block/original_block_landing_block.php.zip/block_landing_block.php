<?php

/**
* landing block
*
* @date Dec 1 2011
* @name James
* @package   blocks
*/

// The links that get provided are a little hacky, 
// but they should work presuming that nobody puts an
// http:// into the url bar.
// 
// I really need a better system for dealing with those
// urls


require_once($CFG->dirroot . '/lib/weblib.php');
require_once($CFG->dirroot . '/lib/formslib.php');
//require_once($CFG->dirroot . '/umoodle.php');

class block_landing_block extends block_base {
    
    public function init() {
        $this->title = get_string('pluginname', "block_landing_block");
    }
    
    /* record if we have already generated the content */
    private $generated = false;
    
    /**
    * block contents
    *
    * @return object
    */
    public function get_content() {
        global $USER, $CFG, $OUTPUT;

        /* First check if we have already generated, don't waste cycles */
        if ($this->generated === true) {

            return $this->content;
        }

        $this->content         = new stdClass();
        
        // error_log("What is cfg root: ".$CFG->wwwroot);
        if($CFG->wwwroot == "http://umoodle25"){
            $SITE_ROOT = "https://moodle-dev.uleth.ca";
            $ICON_ROOT = $CFG->wwwroot;
            
        }else{
            $SITE_ROOT = $CFG->root;
            $ICON_ROOT = $CFG->wwwroot;
        }

        $this->content->text = "
            <script type='text/javascript' language='JavaScript'>
            
                function crdc_get_display_style(d)    { 
                    return document.getElementById(d).style.display;
                }
                function crdc_set_display_style(d, s) { 

                    document.getElementById(d).style.display = s;

                    var image = document.getElementById(d + '_img');
                    var path  = '".$ICON_ROOT."/blocks/landing_block/';
                    var icon  = 'expanded.png';
                    if (s == 'none') {
                        icon = 'collapsed.png';
                    }
                    image.src = path + icon;
                }
                function toggle_display(d) {
                    
                    if (crdc_get_display_style(d) == 'none') { 
                        crdc_set_display_style(d, 'block');
                    } else {
                        crdc_set_display_style(d, 'none');
                    }
                }
            
            </script>";

        $this->content->footer = '';

        $landings =
        array('current_title'   => array($CFG->block_landing_block_showCurrUrl,     $CFG->block_landing_block_currentUrl),
            'long_term_title' => array($CFG->block_landing_block_showLongTermUrl, $CFG->block_landing_block_longTermUrl),
            'past_title'      => array($CFG->block_landing_block_showPastUrl,     $CFG->block_landing_block_pastUrl),
            'future_title'    => array($CFG->block_landing_block_showFutureUrl,   $CFG->block_landing_block_futureUrl),
        );

        /* we only want to display the current courses off the start,
        the user can then optionally open more */
        $first = true;

        foreach ($landings as $name => $landing) {

            /* chop the input in two */
            list($show, $url) = $landing;

            // // error_log("0. get_landing_content() URL: ".$url);
            if (!$show || !$url) {
                continue;
            }

            /* just to be safe, we'll parse the incomming uri, and add the
            portions we need explicitly.  The uris were are passed
            usually have no protocol listed, so they get interpreted as
            just a 'path'.  We quickly check if this is the case, and
            then build a proper uri.  If we get anything else, we'll
            assume it's a full uri and move along. */
            $components = parse_url($url);
            // // error_log("1. get_landing_content() components: ".$components);
            
            if (count($components) == 1 && !empty($components['path'])) {
                $url = 'https://' . $url;
            }
            $url .= 'blocks/landing_block/return.php';
            // // error_log("2. get_landing_content() URL: ".$url);
            
            $icon  = html_writer::empty_tag('img', array('src' => $ICON_ROOT . '/blocks/landing_block/' 
            . ($first ? 'expanded.png' : 'collapsed.png'),
            'class' => 'icon', 'id' => $name . '_img'));

            $link  = html_writer::tag('a', $icon . get_string($name, 'block_landing_block'),
            array('href' => 'javascript:toggle_display(\'' . $name . '\')'));
            
            $title = html_writer::tag('p', $link);
            $text  = '';

            $username = null;

            if(isset($USER->username))
                $username = $USER->username;

            // error_log("get_landing_content() URL: ".$url);
            
            if (False === ($content = $this->get_landing_content($url, $username))) {

                // error_log("get_landing_content() call is FALSE");
                $text .= $title;
                $text .= '<span style="margin-left:10px">';
                $text .= get_string('connection_error', 'block_landing_block');
                $text .= html_writer::link($url . '/my', 'Click Here.');
                $text .= '</span>';

            } else {

                // error_log("get_landing_content() call is TRUE");
                // error_log("what is content: ");
                // error_log($content);

                switch ($content) {
                    case "no user found":
                        /* don't display anything for now, I guess */
                    break;

                    case "no course":
                        /* we only want to display the 'no courses' warning for the current term */
                        if ($first) {
                            $text .= $title;
                            $style = 'margin-left:10px';
                            $text .= html_writer::tag('span', get_string('no_course', 'block_landing_block'),
                            array('id' => $name, 'style' => $style));
                        }
                    break;

                    default:
                        $text .= $title;
                        $style = 'display:' . ($first ? 'block' : 'none') . ';';
                        $text .= html_writer::tag('span', $content, array('id' => $name, 'style' => $style));
                    break;
                }
            }

            /* push the constructed text in to the body */
            $this->content->text .= $text;

            /* indepent of whether we displayed anything for the current
            courses, we will hide the rest */
            $first = false;
        }

        /* set content generated to true so that we know it has been done */
        $generated = true;

        return $this->content;
    }
    
    /**
    * get_landing_content
    * requests a url and id, commplets a curl request
    * in order to get the classes on a remote server
    * @param  string $url the url of the server
    * @param  int $id  id of the student requesting it
    * @return string
    */
    private function get_landing_content($url, $username){
        global $CFG;
        // error_log("get_landing_content() what is username: ".$username);
	    if($CFG->wwwroot == "http://umoodle25"){
            $username = "david.lowe";
        }

        $key    = $CFG->block_landing_block_secret;
        $secret = sha1($key);
        /* query the remote Moodle instance for the data we want */
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->block_landing_block_postimeout);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'secret=' .$secret . '&username=' . $username);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); /* should be default */
        
        if (!($html = curl_exec($ch))) { 
            /* don't push the error to the user, it'll just confuse them */
        }

        curl_close($ch);
        
    	return $html;
    }
    
    /*
    * allow the block to have a configuration page
    *
    * @return boolean
    */
    function has_config() {
        return true;
    }

    /**
    * locations where block can be displayed
    *
    * @return array
    */
    function applicable_formats() {
        return array('all'=>true);
    }
    /**
     * Used to no display the header
     * @return bool
     */
    function hide_header() {
        return true;
    }
    
    /**
     * The block cannot be hidden by default as it is integral to
     * the navigation of Moodle.
     *
     * @return false
     */
    function instance_can_be_hidden() {
        return false;
    }
    
    /**
     * The block cannot be edited by the user as it is integral to the
     * navigation of UofL's Moodle.
     *
     * @return false
     */
    function user_can_edit() {
        return false;
    }
}
?>
